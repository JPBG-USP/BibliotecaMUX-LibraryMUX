
    Biblioteca Multiplexador CD74HC4067 CMOS Analógico Digital 16 canais

        Essa biblioteca foi feita para o projeto de bixo 2022 do Núcleo NRE do SEMEAR - USP São Carlos. Como o Multiplexador(MUX)
        é uma ferramenta muito útil e possivelmente será usada nos proximos anos por outros bixos e integrantes do núcleo eu decidi
        criar uma biblioteca e disponibiliza-la para uso geral, espero que gostem e que ela seja util, abraços.

    by João Pedro Baltieca Garcia
        São Carlos, 21 de Outubro de 2022

	
	Os pinos do Mux são definidos como C0 , C1, C2, ... , C14 e C15
		- Obs: apesar de eu achar que fica mais desorganizado, você também pode usar só o número, como 0, 1, 2, ... , 14 e 15

	* Função digitalWriteMux(int pin, int estado);
	- define um pino do Mux como HIGH ou LOW
	- antes de escolher um pino, ela a define como LOW pra depois definir outro estado.
	- pin = pino do MUX
	- estado = HIGH ou LOW

	* Função choosePinMux(int pino);
	- Escolhe/Seleciona um pino do MUX
	- pin = pino do MUX


